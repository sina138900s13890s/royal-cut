const prices={hair:200000,beard:120000,vip:280000};
const names={hair:"اصلاح مو",beard:"اصلاح ریش",vip:"پکیج VIP"};
const $=id=>document.getElementById(id);
const form=$("bookingForm"), date=$("date"), time=$("time"), service=$("service"), message=$("message");
const key="royalCutBookings";
function price(n){return new Intl.NumberFormat("fa-IR").format(n)+" تومان"}
function today(){const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}
date.min=today();
function bookings(){try{return JSON.parse(localStorage.getItem(key)||"[]")}catch{return []}}
function save(list){localStorage.setItem(key,JSON.stringify(list))}
function updatePrice(){$("price").textContent=prices[service.value]?price(prices[service.value]):"—"}
function updateTimes(){
 const selected=date.value;time.innerHTML="";
 const first=document.createElement("option");first.value="";first.textContent=selected?"انتخاب ساعت":"ابتدا تاریخ را انتخاب کن";time.appendChild(first);if(!selected)return;
 const busy=bookings().filter(b=>b.date===selected).map(b=>b.time);
 for(let h=9;h<=19;h++){for(const m of (h===19?["00"]:["00","30"])){const t=String(h).padStart(2,"0")+":"+m;const o=document.createElement("option");o.value=t;o.textContent=busy.includes(t)?t+" — رزرو شده":t;o.disabled=busy.includes(t);time.appendChild(o)}}
}
function render(){
 const list=bookings();$("bookingList").innerHTML="";
 if(!list.length){$("bookingList").innerHTML="<p>هنوز نوبتی ثبت نشده است.</p>";return}
 list.slice().reverse().forEach(b=>{
  const item=document.createElement("article");item.className="booking-item";
  const info=document.createElement("div"),title=document.createElement("strong"),detail=document.createElement("p");
  title.textContent=b.name+" — "+names[b.service];detail.textContent=`${b.date}، ساعت ${b.time} | ${b.phone} | ${price(prices[b.service])}`;info.append(title,detail);
  const button=document.createElement("button");button.className="cancel";button.type="button";button.textContent="لغو نوبت";
  button.onclick=()=>{save(bookings().filter(x=>x.id!==b.id));render();updateTimes();message.textContent="نوبت لغو شد."};item.append(info,button);$("bookingList").appendChild(item);
 });
}
service.addEventListener("change",updatePrice);date.addEventListener("change",updateTimes);
form.addEventListener("submit",e=>{
 e.preventDefault();const name=$("customerName").value.trim(),phone=$("phone").value.trim(),s=service.value,d=date.value,t=time.value;
 if(!name||!/^09[0-9]{9}$/.test(phone)||!s||!d||!t){message.textContent="لطفاً اطلاعات را کامل و درست وارد کن.";return}
 if(d<today()){message.textContent="تاریخ نمی‌تواند در گذشته باشد.";return}
 const list=bookings();if(list.some(b=>b.date===d&&b.time===t)){message.textContent="این ساعت در همین مرورگر رزرو شده؛ ساعت دیگری انتخاب کن.";updateTimes();return}
 list.push({id:Date.now().toString(),name,phone,service:s,date:d,time:t,notes:$("notes").value.trim()});save(list);render();form.reset();updatePrice();updateTimes();message.textContent="نوبت در همین دستگاه ذخیره شد؛ برای رزرو مشترک همه مشتری‌ها به سرور نیاز است."; $("myBookings").scrollIntoView({behavior:"smooth"});
});
$("clearBookings").addEventListener("click",()=>{if(confirm("همه نوبت‌های این مرورگر پاک شوند؟")){save([]);render();updateTimes();message.textContent="نوبت‌ها پاک شدند."}});
render();updatePrice();updateTimes();